"use client"

import { useState, useEffect } from "react"
import { SparkleEffect } from "./sparkle-effect"
import { HeartParticles } from "./heart-particles"
import { FloatingBalloons } from "./floating-balloons"
import { Heart, Download, FileText } from "lucide-react"

export function EndingScreen() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 300)
  }, [])

  return (
    <div
      className="min-h-screen relative flex items-center justify-center overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%)",
      }}
    >
      <FloatingBalloons />
      <HeartParticles />
      <SparkleEffect />

      <div
        className={`relative z-20 max-w-lg mx-4 text-center transition-all duration-1000 ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
        }`}
      >
        <div className="glass-card rounded-3xl p-8 md:p-12">
          {/* Decorative hearts */}
          <div className="flex justify-center gap-3 mb-6">
            {[...Array(5)].map((_, i) => (
              <Heart
                key={i}
                className="w-6 h-6 text-primary fill-primary animate-float"
                style={{ animationDelay: `${i * 0.3}s` }}
              />
            ))}
          </div>

          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-6 leading-tight text-balance">
            You&apos;re the brightest part of my life.
          </h1>

          <p className="text-lg text-muted-foreground mb-4">Thank you for being you.</p>

          <p className="text-2xl font-serif text-primary mb-8">Happy 23rd Birthday, my love.</p>

          {/* Action buttons */}
          <div className="space-y-4">
            <button className="w-full px-6 py-4 bg-primary text-primary-foreground rounded-2xl font-medium text-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-3">
              <Download className="w-5 h-5" />
              Download Birthday Wallpaper
            </button>

            <button className="w-full px-6 py-4 bg-secondary text-secondary-foreground rounded-2xl font-medium text-lg hover:bg-secondary/80 transition-colors flex items-center justify-center gap-3">
              <FileText className="w-5 h-5" />
              Read My Love Letter
            </button>
          </div>

          {/* Final heart animation */}
          <div className="mt-8 flex justify-center">
            <div className="relative">
              <Heart
                className="w-16 h-16 text-primary fill-primary animate-pulse"
                style={{ filter: "drop-shadow(0 0 20px rgba(236, 72, 153, 0.5))" }}
              />
              <div className="absolute inset-0 animate-ping">
                <Heart className="w-16 h-16 text-primary/30 fill-primary/30" />
              </div>
            </div>
          </div>

          <p className="mt-6 text-sm text-muted-foreground">Made with all my love, just for you</p>
        </div>
      </div>
    </div>
  )
}
