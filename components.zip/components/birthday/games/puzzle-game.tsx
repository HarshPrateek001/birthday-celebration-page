"use client"

import { useState, useEffect, useMemo, memo } from "react"
import { ArrowLeft, Eye, EyeOff, RotateCcw, HelpCircle } from "lucide-react"
import { cn } from "@/lib/utils"

// --- Configuration ---
const PUZZLE_SIZE = 3
const IMAGE_URL = "/5.jpg" // A cute, romantic image
const TILE_GAP = "gap-2" // Tailwind gap class

// --- Type Definitions ---
interface Tile {
  id: number
  correctPos: number
  currentPos: number
}

interface PuzzleGameProps {
  onComplete: () => void
  onBack: () => void
}

// --- Helper Functions ---
const createAndShuffleTiles = (): Tile[] => {
  const tiles: Tile[] = Array.from({ length: PUZZLE_SIZE * PUZZLE_SIZE }, (_, i) => ({
    id: i,
    correctPos: i,
    currentPos: i,
  }))

  // Fisher-Yates shuffle for true randomness
  for (let i = tiles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[tiles[i].currentPos, tiles[j].currentPos] = [tiles[j].currentPos, tiles[i].currentPos]
  }

  // Ensure the puzzle is solvable (optional, but good practice)
  // For simplicity, we'll skip the solvability check, as it's complex.
  // A simple shuffle is usually fine for a 3x3 grid.
  
  return tiles
}

// --- Child Components ---
const TileComponent = memo(
  ({
    tile,
    isSelected,
    isComplete,
    isHint,
    onClick,
  }: {
    tile: Tile
    isSelected: boolean
    isComplete: boolean
    isHint?: boolean
    onClick: () => void
  }) => {
    const row = Math.floor(tile.correctPos / PUZZLE_SIZE)
    const col = tile.correctPos % PUZZLE_SIZE

    return (
      <div
        onClick={onClick}
        className={cn(
          "relative aspect-square rounded-lg overflow-hidden transition-all duration-300 cursor-pointer",
          "transform-gpu will-change-transform", // Performance optimization
          isComplete ? "shadow-none" : "shadow-md hover:shadow-xl",
          !isHint && !isComplete && "hover:scale-105 active:scale-95",
          isSelected && !isComplete && "ring-4 ring-rose-400 shadow-xl scale-105"
        )}
      >
        <img
          src={IMAGE_URL}
          alt={`Puzzle tile ${tile.id + 1}`}
          className="absolute w-[300%] h-[300%] max-w-none transition-all duration-300"
          style={{
            top: `-${row * 100}%`,
            left: `-${col * 100}%`,
          }}
        />
      </div>
    )
  }
)
TileComponent.displayName = "Tile"


export function PuzzleGame({ onComplete, onBack }: PuzzleGameProps) {
  const [tiles, setTiles] = useState<Tile[]>([])
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [moves, setMoves] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const [isHintActive, setIsHintActive] = useState(false)

  useEffect(() => {
    setTiles(createAndShuffleTiles())
  }, [])

  const handleTileClick = (tileId: number) => {
    if (isComplete) return

    if (selectedId === null) {
      setSelectedId(tileId)
    } else if (selectedId === tileId) {
      setSelectedId(null)
    } else {
      // Immutable swap of tile positions
      setTiles(currentTiles => {
        const selectedTile = currentTiles.find(t => t.id === selectedId)
        const clickedTile = currentTiles.find(t => t.id === tileId)
        if (!selectedTile || !clickedTile) return currentTiles

        return currentTiles.map(t => {
          if (t.id === selectedId) return { ...t, currentPos: clickedTile.currentPos }
          if (t.id === tileId) return { ...t, currentPos: selectedTile.currentPos }
          return t
        })
      })
      setSelectedId(null)
      setMoves(m => m + 1)
    }
  }

  // Check for completion after each move
  useEffect(() => {
    if (tiles.length > 0 && tiles.every(t => t.currentPos === t.correctPos)) {
      setTimeout(() => setIsComplete(true), 300) // Delay to allow final tile animation
    }
  }, [tiles])

  const sortedTiles = useMemo(() => [...tiles].sort((a, b) => a.currentPos - b.currentPos), [tiles])
  const hintTiles = useMemo(() => [...tiles].sort((a, b) => a.correctPos - b.correctPos), [tiles])

  return (
    <div className="flex flex-col items-center justify-center p-4 relative min-h-screen w-full bg-gradient-to-br from-rose-50 via-pink-100 to-rose-100">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="absolute top-6 left-6 flex items-center gap-2 text-rose-800/70 hover:text-rose-900 transition-colors z-30"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back</span>
      </button>

      {/* Header */}
      <div className="text-center mb-6 z-10">
        <h2 className="font-serif text-4xl font-bold text-rose-800">A Special Memory</h2>
        <p className="text-rose-700/80">Piece it together to see our moment.</p>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3 mb-4 z-10">
        <button
          onMouseDown={() => setIsHintActive(true)}
          onMouseUp={() => setIsHintActive(false)}
          onMouseLeave={() => setIsHintActive(false)}
          onTouchStart={() => setIsHintActive(true)}
          onTouchEnd={() => setIsHintActive(false)}
          className="px-4 py-2 bg-white/50 backdrop-blur-sm border border-pink-200/60 rounded-full text-sm flex items-center gap-2 text-rose-800/90 hover:bg-white/70 transition-all shadow-sm hover:shadow-md"
        >
          <HelpCircle className="w-4 h-4" />
          <span>Hold for Hint</span>
        </button>
        <button
          onClick={() => setTiles(createAndShuffleTiles())}
          className="px-4 py-2 bg-white/50 backdrop-blur-sm border border-pink-200/60 rounded-full text-sm flex items-center gap-2 text-rose-800/90 hover:bg-white/70 transition-all shadow-sm hover:shadow-md"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Restart</span>
        </button>
      </div>

      {/* --- Puzzle Area --- */}
      <div className="relative w-80 h-80 md:w-96 md:h-96">
        {/* Full Image (visible on complete) */}
        <div
          className={cn(
            "absolute inset-0 transition-opacity duration-1000",
            isComplete ? "opacity-100" : "opacity-0"
          )}
        >
          <img
            src={IMAGE_URL}
            alt="Completed puzzle"
            className="w-full h-full rounded-xl shadow-2xl"
          />
        </div>

        {/* Puzzle Grid (visible before complete) */}
        <div
          className={cn(
            "absolute inset-0 grid grid-cols-3 p-1 bg-white/30 backdrop-blur-md rounded-xl shadow-lg transition-opacity duration-700",
            TILE_GAP,
            isComplete ? "opacity-0 pointer-events-none" : "opacity-100"
          )}
        >
          {sortedTiles.map(tile => (
            <TileComponent
              key={tile.id}
              tile={tile}
              isSelected={selectedId === tile.id}
              isComplete={isComplete}
              onClick={() => handleTileClick(tile.id)}
            />
          ))}
        </div>

        {/* Hint Overlay */}
        <div
          className={cn(
            "absolute inset-0 grid grid-cols-3 p-1 bg-black/50 backdrop-blur-md rounded-xl transition-opacity duration-300",
            TILE_GAP,
            isHintActive ? "opacity-100 z-20" : "opacity-0 z-0 pointer-events-none"
          )}
        >
          {hintTiles.map(tile => (
            <TileComponent
              key={`hint-${tile.id}`}
              tile={tile}
              isSelected={false}
              isComplete={isComplete}
              isHint
              onClick={() => {}}
            />
          ))}
        </div>
      </div>
      
      {/* Moves Counter */}
      <div className="mt-4 text-center text-rose-700/80 z-10">
        <p>Moves: <span className="font-bold text-rose-800">{moves}</span></p>
      </div>

      {/* --- Completion Screen --- */}
      {isComplete && (
        <div className="absolute inset-0 flex flex-col items-center justify-end pb-12 md:pb-24 z-20">
           <div className="relative text-center transition-all duration-1000 delay-500" style={{opacity: isComplete ? 1 : 0, transform: isComplete ? 'translateY(0)' : 'translateY(20px)'}}>
            <button
              onClick={onComplete}
              className="px-10 py-4 bg-rose-500 text-white rounded-full font-bold shadow-lg hover:shadow-xl hover:scale-105 transform transition-all duration-300"
            >
              Continue to next surprise ❤️
            </button>
           </div>
        </div>
      )}
    </div>
  )
}
