"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowLeft, Heart } from "lucide-react"

interface LoveMeterProps {
  onComplete: () => void
  onBack: () => void
}

export function LoveMeter({ onComplete, onBack }: LoveMeterProps) {
  const [value, setValue] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const [hearts, setHearts] = useState<{ id: number; x: number; delay: number }[]>([])
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (value >= 100 && !isComplete) {
      setIsComplete(true)
      // Burst of hearts
      const newHearts = Array.from({ length: 30 }, (_, i) => ({
        id: Date.now() + i,
        x: Math.random() * 100,
        delay: Math.random() * 0.5,
      }))
      setHearts(newHearts)
    }
  }, [value, isComplete])

  const getMessage = () => {
    if (value < 25) return "Keep going..."
    if (value < 50) return "Getting warmer!"
    if (value < 75) return "Almost there!"
    if (value < 100) return "So close!"
    return "To infinity and beyond!"
  }

  return (
    <div ref={containerRef} className="text-center relative">
      <button
        onClick={onBack}
        className="absolute top-4 left-4 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back
      </button>

      {/* Floating hearts burst */}
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute bottom-1/2 pointer-events-none"
          style={{
            left: `${heart.x}%`,
            animation: `heart-float 2s ease-out ${heart.delay}s forwards`,
          }}
        >
          <Heart className="w-6 h-6 text-primary fill-primary" />
        </div>
      ))}

      <h2 className="font-serif text-3xl text-foreground mb-2">Love Meter</h2>
      <p className="text-muted-foreground mb-8">How much do I love you? Find out!</p>

      <div className="glass-card rounded-3xl p-8 max-w-md mx-auto">
        {/* Meter display */}
        <div className="mb-8">
          <div className="text-6xl font-bold text-primary mb-2">{value}%</div>
          <p className="text-lg text-foreground font-medium">{getMessage()}</p>
        </div>

        {/* Heart container */}
        <div className="relative w-32 h-32 mx-auto mb-8">
          <div
            className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
            style={{ transform: `scale(${0.8 + value * 0.005})` }}
          >
            <Heart
              className="w-full h-full text-primary transition-all duration-300"
              style={{
                fill: `rgba(236, 72, 153, ${value / 100})`,
                filter: isComplete ? "drop-shadow(0 0 20px rgba(236, 72, 153, 0.8))" : "none",
              }}
            />
          </div>
          {isComplete && (
            <div className="absolute inset-0 animate-ping">
              <Heart className="w-full h-full text-primary/30 fill-primary/30" />
            </div>
          )}
        </div>

        {/* Slider */}
        <div className="space-y-4">
          <input
            type="range"
            min="0"
            max="100"
            value={value}
            onChange={(e) => setValue(Number(e.target.value))}
            className="w-full h-3 bg-muted rounded-full appearance-none cursor-pointer accent-primary"
            style={{
              background: `linear-gradient(to right, var(--primary) 0%, var(--primary) ${value}%, var(--muted) ${value}%, var(--muted) 100%)`,
            }}
          />
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>0</span>
            <span>Infinite</span>
          </div>
        </div>
      </div>

      {isComplete && (
        <div className="mt-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <p className="text-primary font-medium text-lg mb-4">My love for you goes beyond any number!</p>
          <button
            onClick={onComplete}
            className="px-8 py-4 bg-primary text-primary-foreground rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Continue
          </button>
        </div>
      )}
    </div>
  )
}
