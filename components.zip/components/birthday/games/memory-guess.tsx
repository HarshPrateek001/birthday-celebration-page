"use client"

import { useState } from "react"
import { ArrowLeft, CheckCircle2 } from "lucide-react"
import Image from "next/image"

interface MemoryGuessProps {
  onComplete: () => void
  onBack: () => void
}

interface Memory {
  id: number
  src: string
  caption: string
  revealed: boolean
}

export function MemoryGuess({ onComplete, onBack }: MemoryGuessProps) {
  const [memories, setMemories] = useState<Memory[]>([
    { id: 1, src: "/romantic-memory-1.jpg", caption: "Our first adventure together", revealed: false },
    { id: 2, src: "/romantic-memory-2.jpg", caption: "The day we couldn't stop laughing", revealed: false },
    { id: 3, src: "/romantic-memory-3.jpg", caption: "When everything felt perfect", revealed: false },
  ])
  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null)

  const handleReveal = (id: number) => {
    const memory = memories.find((m) => m.id === id)
    if (memory && !memory.revealed) {
      setSelectedMemory(memory)
      setMemories((prev) => prev.map((m) => (m.id === id ? { ...m, revealed: true } : m)))
    }
  }

  const allRevealed = memories.every((m) => m.revealed)

  return (
    <div className="text-center">
      <button
        onClick={onBack}
        className="absolute top-4 left-4 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back
      </button>

      <h2 className="font-serif text-3xl text-foreground mb-2">Guess the Memory</h2>
      <p className="text-muted-foreground mb-8">
        {allRevealed ? "All memories revealed!" : "Tap to reveal hidden memories"}
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
        {memories.map((memory) => (
          <button
            key={memory.id}
            onClick={() => handleReveal(memory.id)}
            disabled={memory.revealed}
            className={`glass-card rounded-2xl overflow-hidden transition-all duration-500 ${
              memory.revealed ? "cursor-default" : "cursor-pointer hover:scale-105"
            }`}
          >
            <div className="relative aspect-square">
              <Image
                src={memory.src || "/placeholder.svg"}
                alt="Memory"
                fill
                className={`object-cover transition-all duration-700 ${memory.revealed ? "blur-0" : "blur-xl"}`}
              />
              {!memory.revealed && (
                <div className="absolute inset-0 bg-primary/30 flex items-center justify-center">
                  <span className="text-4xl">?</span>
                </div>
              )}
            </div>
            {memory.revealed && (
              <div className="p-4 animate-in fade-in duration-500">
                <p className="text-sm text-foreground italic">&ldquo;{memory.caption}&rdquo;</p>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Revealed memory modal */}
      {selectedMemory && (
        <div
          className="fixed inset-0 z-50 bg-foreground/80 backdrop-blur flex items-center justify-center p-4"
          onClick={() => setSelectedMemory(null)}
        >
          <div className="glass-card rounded-3xl overflow-hidden max-w-sm w-full animate-in zoom-in duration-300">
            <div className="relative aspect-square">
              <Image src={selectedMemory.src || "/placeholder.svg"} alt="Memory" fill className="object-cover" />
            </div>
            <div className="p-6">
              <p className="text-lg text-foreground italic text-center">&ldquo;{selectedMemory.caption}&rdquo;</p>
            </div>
          </div>
        </div>
      )}

      {allRevealed && (
        <div className="mt-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center justify-center gap-2 text-primary mb-4">
            <CheckCircle2 className="w-6 h-6" />
            <span className="font-medium text-lg">Every memory with you is precious!</span>
          </div>
          <button
            onClick={onComplete}
            className="px-8 py-4 bg-primary text-primary-foreground rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Continue
          </button>
        </div>
      )}
    </div>
  )
}
